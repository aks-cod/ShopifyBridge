﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_CRUD.Model
{
    public class ItemsContext:DbContext
    {
        public ItemsContext(DbContextOptions<ItemsContext> options ):base (options)
        {

        }

        public DbSet<ItemsModel> Items { get; set; }
    }
}
