﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopBridge_CRUD.ItemsData;
using ShopBridge_CRUD.Model;

namespace ShopBridge_CRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShopBridgeInventoryController : ControllerBase
    {
        public IItemsData _items;
        public ShopBridgeInventoryController(IItemsData items)
        {
            _items = items;
        }
        [HttpGet]
        [Route("api/(Controller)")]
        public IActionResult GetAllItems()
        {
            return Ok(_items.GetAllItems());
        }
        [HttpGet]
        [Route("api/(Controller)/{id}")]
        public IActionResult GetItem(int id)
        {
            var item = _items.GetItem(id);
            if (item != null)
            {
                return Ok(item);
            }
            else
            {
                return NotFound("Item not found");
            }
        }
        [HttpPost]
        [Route("api/(Controller)")]
        public IActionResult AddItems(ItemsModel itemModel)
        {
            _items.AddItems(itemModel);
            return Created($"{HttpContext.Request.Scheme} :// {HttpContext.Request.Host}  {HttpContext.Request.Path} / {itemModel.ID}", itemModel);
        }
        [HttpDelete]
        [Route("api/(Controller)/{id}")]
        public IActionResult DeleteItem(int id)
        {
            var findItem = _items.GetItem(id);
            if (findItem != null)
            {
                return Ok();
            }
            else
            {
                return NotFound($"Item not found to delete for id {id}");
            }
        }
        [HttpPatch]
        [Route("api/(Controller)/{id}")]
        public IActionResult UpdateItem(int id,ItemsModel items)
        {
            var findItem = _items.GetItem(id);
            if (findItem != null)
            {
                items.ID = findItem.ID;
                _items.UpdateItem(items);
            }
            return Ok(items);
        }
    }
}
