﻿using ShopBridge_CRUD.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_CRUD.ItemsData
{
    public interface IItemsData
    {
        public List<ItemsModel> GetAllItems();
        public ItemsModel GetItem(int ID);
        public ItemsModel AddItems(ItemsModel items);
        public void DeleteItem(ItemsModel items);
        public ItemsModel UpdateItem(ItemsModel items);


    }
}
