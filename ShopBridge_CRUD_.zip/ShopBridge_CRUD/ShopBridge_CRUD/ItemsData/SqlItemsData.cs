﻿using ShopBridge_CRUD.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge_CRUD.ItemsData
{
    public class SqlItemsData : IItemsData
    {
        private ItemsContext _itemsContext;
        public SqlItemsData(ItemsContext itemsContext)
        {
            _itemsContext = itemsContext;
        }
        public ItemsModel AddItems(ItemsModel items)
        {
            try
            {

                Random random = new Random();
                items.ID = random.Next();
                _itemsContext.Items.Add(items);
                _itemsContext.SaveChanges();
                return items;
            }
            catch(NullReferenceException)
            {
                return null;
            }
        }

        public void DeleteItem(ItemsModel items)
        {
            _itemsContext.Items.Remove(items);
            _itemsContext.SaveChanges();
            
        }

        public List<ItemsModel> GetAllItems()
        {
            return _itemsContext.Items.ToList();
        }

        public ItemsModel GetItem(int ID)
        {
            var item = _itemsContext.Items.Find(ID);
            return item;
        }

        public ItemsModel UpdateItem(ItemsModel items)
        {
            var findItem = _itemsContext.Items.Find(items.ID);
            if(findItem !=null)
            {
                _itemsContext.Items.Update(items);
                _itemsContext.SaveChanges();
            }
            return items;
        }
    }
}
