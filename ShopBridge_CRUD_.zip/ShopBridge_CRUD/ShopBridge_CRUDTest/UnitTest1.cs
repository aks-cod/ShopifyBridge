using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using ShopBridge_CRUD.Controllers;
using ShopBridge_CRUD.ItemsData;
using ShopBridge_CRUD.Model;

namespace ShopBridge_CRUDTest
{
    [TestClass]
    public class UnitTest1
    {
        public Mock<IItemsData> _items;
        public ShopBridgeInventoryController shopBridgeInventoryController;
        public UnitTest1()
        {
            _items = new Mock<IItemsData>();
            shopBridgeInventoryController = new ShopBridgeInventoryController(_items.Object);
        }
        [TestMethod]
        public void GetAllItems_Test()
        {
            _items.Setup(m => m.GetAllItems()).Returns(new System.Collections.Generic.List<ItemsModel>()
            { new ItemsModel()
            {
                ID = 1,
                ItemName = "Chocolates",
                Description = "Belgium Nut, dark Chocolate",
                Price = 100.01f,
                Quantity = "15"
            }
            });
            var Result = shopBridgeInventoryController.GetAllItems() as OkObjectResult;
            Assert.AreEqual(Result.StatusCode,200);
        }
        [TestMethod]
        public void GetItem_Test()
        {
            _items.Setup(m => m.GetItem(It.IsAny<int>())).Returns(new ItemsModel() { ID=2});
            var Result = shopBridgeInventoryController.GetAllItems() as OkObjectResult;
            Assert.AreEqual(Result.StatusCode, 200);
        }
        [TestMethod]
        public void DeleteItems_Test()
        {
            _items.Setup(m => m.DeleteItem(It.IsAny<ItemsModel>()));
            var Result = shopBridgeInventoryController.GetAllItems() as OkObjectResult;
            Assert.AreEqual(Result.StatusCode, 200);
        }
        [TestMethod]
        public void AddItems_Test()
        {
            _items.Setup(m => m.AddItems(It.IsAny<ItemsModel>())).Returns(new ItemsModel()
            {
                ID = 1,
                ItemName = "Chocolates",
                Description = "Belgium Nut, dark Chocolate",
                Price = 100.01f,
                Quantity = "15"
            });
            var Result = shopBridgeInventoryController.GetAllItems() as OkObjectResult;
            Assert.AreEqual(Result.StatusCode, 200);
        }
        [TestMethod]
        public void EditItems_Test()
        {
            _items.Setup(m => m.UpdateItem(It.IsAny<ItemsModel>())).Returns(new ItemsModel()
            {
                ID = 1,
                ItemName = "Chocolates",
                Description = "Belgium Nut, dark Chocolate",
                Price = 100.01f,
                Quantity = "15"
            });
            var Result = shopBridgeInventoryController.GetAllItems() as OkObjectResult;
            Assert.AreEqual(Result.StatusCode, 200);
        }

    }
}
